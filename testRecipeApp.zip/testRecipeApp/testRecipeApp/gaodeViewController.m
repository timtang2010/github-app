//
//  gaodeViewController.m
//  testRecipeApp
//
//  Created by yuxin tang on 14-4-16.
//  Copyright (c) 2014年 v5mcs. All rights reserved.
//

#import "gaodeViewController.h"

@interface gaodeViewController ()

@end

@implementation gaodeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated
{
    
    [MAMapServices sharedServices].apiKey = @"9156df152c43e9ab456157f8b9c3e477";
    
    [super viewWillAppear:animated];
    //高德地图
    // battery 20 nav 44
    int statusHeight = 64;
    self.mapView = [[MAMapView alloc]initWithFrame:CGRectMake(0, statusHeight, 320, 568 - 108)];
    self.mapView.delegate = self;
    [self.view addSubview:self.mapView];
    //黑框
    int myViewPosY = self.mapView.frame.origin.y + self.mapView.frame.size.height;
    UIView *myview = [[UIView alloc]initWithFrame:CGRectMake(0, myViewPosY, 320, 568 - myViewPosY)];
    myview.backgroundColor = [UIColor blackColor];
    //按钮
    //    UIButton * btn = [UIButton buttonWithType:UIButtonTypeContactAdd];
    //    btn.frame = CGRectMake(20, 20, 30, 30);
    //    [myview addSubview:btn];
    //分页栏
    UISegmentedControl * seg1 = [[UISegmentedControl alloc] initWithItems:@[@"开始", @"停止"]];
    UISegmentedControl * seg2 = [[UISegmentedControl alloc] initWithItems:@[@"无", @"跟随", @"头"]];
    [myview addSubview:seg1];
    [myview addSubview:seg2];
    
    seg1.frame = CGRectMake(22, 7, 90, 30);
    seg2.frame = CGRectMake(132, 7, 150, 30);
    [self.view addSubview:myview];}

//- (void) setUpSegmentedControl
//{
//    UIBarButtonItem *flexble = [[UIBarButtonItem alloc]
//                                //空白到其他项目之间添加。该空间中的其他项目之间平均分配。
//                                initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace
//                                target:nil
//                                action:nil];
//    
//    self.showSegment = [[UISegmentedControl alloc]
//                        initWithItems:[NSArray arrayWithObjects:
//                                       @"Start",
//                                       @"Stop",
//                                       nil]];
//    
////    self.showSegment.segmentedControlStyle = UISegmentedControlStyleBar;
//    
//    [self.showSegment addTarget:self
//                         action:@selector(showsSegmentAction:)
//               forControlEvents:UIControlEventValueChanged];
//    
//    self.showSegment.selectedSegmentIndex = 0;
//    
//    UIBarButtonItem *showItem = [[UIBarButtonItem alloc]
//                                 initWithCustomView:self.showSegment];
//    
//    self.modeSegment = [[UISegmentedControl alloc]
//                        initWithItems:
//                        [NSArray arrayWithObjects:
//                         @"None",
//                         @"Follow",
//                         @"Head", nil]];
//    
//
//    
//    [self.modeSegment addTarget:self
//                         action:@selector(modeAction:)
//               forControlEvents:UIControlEventValueChanged];
//    
//    self.modeSegment.selectedSegmentIndex = 0;
//    UIBarButtonItem *modeItem = [[UIBarButtonItem alloc]
//                                 initWithCustomView:self.modeSegment];
//    
//    self.toolbarItems = [NSArray arrayWithObjects:
//                         flexble,
//                         showItem,
//                         flexble,
//                         modeItem,
//                         flexble,
//                         nil];
//    
////    //创建
////    UISegmentedControl *mySegmentedControl = [[UISegmentedControl alloc]initWithItems:nil];
//////    //设置item的宽度
//////    [mySegmentedControl setWidth:50 forSegmentAtIndex:0];
////    
////    [mySegmentedControl insertSegmentWithTitle:@"开始"
////                                       atIndex:0
////                                      animated:YES];
////    [mySegmentedControl insertSegmentWithTitle:@"停止"
////                                       atIndex:1
////                                      animated:YES];
////    [self.mapView addSubview:mySegmentedControl];
//    
//}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
