//
//  GRServiceEvaluationWithMyCell_TableViewCell.h
//  Community
//
//  Created by WEB08-V5MCS006 on 14-4-9.
//  Copyright (c) 2014年 v5mcs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RSTapRateView.h"

@interface GRServiceEvaluationWithMyCell_TableViewCell : UITableViewCell <RSTapRateViewDelegate>

@property (strong, nonatomic) UILabel * label;

@property (strong, nonatomic) RSTapRateView * tapRateView;

@end
