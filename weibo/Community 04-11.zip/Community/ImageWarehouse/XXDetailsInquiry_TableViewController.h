//
//  XXDetailsInquiry_TableViewController.h
//  Community
//
//  Created by yuxin tang on 14-4-9.
//  Copyright (c) 2014年 v5mcs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XXDetailsInquiry_TableViewController : UITableViewController

@property (strong, nonatomic) NSArray *listData;

@end
