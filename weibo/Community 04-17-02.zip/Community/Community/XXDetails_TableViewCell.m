//
//  XXDetails_TableViewCell.m
//  Community
//
//  Created by yuxin tang on 14-4-9.
//  Copyright (c) 2014年 v5mcs. All rights reserved.
//

#import "XXDetails_TableViewCell.h"

@implementation XXDetails_TableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
