//
//  YYService_NavigationController.h
//  Community
//
//  Created by WEB08-V5MCS006 on 14-4-10.
//  Copyright (c) 2014年 v5mcs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YYService_NavigationController : UINavigationController

@end
