//
//  GRAboutUs_ViewController.h
//  Community
//
//  Created by WEB08-V5MCS006 on 14-4-2.
//  Copyright (c) 2014年 v5mcs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GRAboutUs_ViewController : UIViewController

@property (strong, nonatomic) UIImageView * imageView;

@end
