//
//  GRMyOrderWithMyCell_TableViewCell.h
//  Community
//
//  Created by WEB08-V5MCS006 on 14-4-9.
//  Copyright (c) 2014年 v5mcs. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol TurnToGRServiceEvaluation_ViewController;

@interface GRMyOrderWithMyCell_TableViewCell : UITableViewCell

//订单编号Label
@property (strong, nonatomic) UILabel * orderNumberLabel;
//下单日期Label
@property (strong, nonatomic) UILabel * orderDataLabel;
//服务内容Label
@property (strong, nonatomic) UILabel * serveContentLabel;
//订单状态Label
@property (strong, nonatomic) UILabel * orderStateLabel;
//订单评价Button
@property (strong, nonatomic) UIButton * orderEvaluateButton;

@property (strong, nonatomic) UIImageView * imgLines;

@property (strong, nonatomic) id <TurnToGRServiceEvaluation_ViewController> delegate;

- (void)drawRect:(CGRect)rect;

@end
