//
//  RootTabBar_ViewController.h
//  Community
//
//  Created by WEB08-V5MCS006 on 14-4-1.
//  Copyright (c) 2014年 v5mcs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootTabBar_ViewController : UITabBarController

@property (strong, nonatomic) NSMutableArray * images;
@property (strong, nonatomic) NSMutableArray * selectImages;
@property (assign, nonatomic) int trueSelectedIndex;

- (void)createCustomTabBar;//声明自定义tabBar方法
- (void)createSpaceImageView;//声明间隔图片的创建方法
- (void)swipeCallBack:(UISwipeGestureRecognizer *)sender;//声明手势回调函数
- (void)hideCustomTabBar:(BOOL)hide;//声明隐藏自定义tabBar的方法，需要隐藏，只需要调用就可以
+ (id)getInstance;//声明获取单例方法

@end
