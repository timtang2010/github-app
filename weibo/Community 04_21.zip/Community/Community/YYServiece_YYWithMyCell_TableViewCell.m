//
//  YYServiece_YYWithMyCell_TableViewCell.m
//  Community
//
//  Created by WEB08-V5MCS006 on 14-4-10.
//  Copyright (c) 2014年 v5mcs. All rights reserved.
//

#import "YYServiece_YYWithMyCell_TableViewCell.h"

@implementation YYServiece_YYWithMyCell_TableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.label = [[UILabel alloc]initWithFrame:CGRectMake(0, 2, 320, 45)];
        self.label.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:self.label];
    }
    
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

@end
