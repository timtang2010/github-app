//
//  GRAboutUs_ViewController.m
//  Community
//
//  Created by WEB08-V5MCS006 on 14-4-2.
//  Copyright (c) 2014年 v5mcs. All rights reserved.
//

#import "GRAboutUs_ViewController.h"

@interface GRAboutUs_ViewController ()

@end

@implementation GRAboutUs_ViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 64, 320, 455)];
    [self.imageView setImage:[UIImage imageNamed:@"个人中心-设置-关于我们.png"]];
    [self.view addSubview:self.imageView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
