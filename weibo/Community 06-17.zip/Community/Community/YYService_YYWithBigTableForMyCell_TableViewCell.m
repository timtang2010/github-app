//
//  YYService_YYWithBigTableForMyCell_TableViewCell.m
//  Community
//
//  Created by WEB08-V5MCS006 on 14-4-12.
//  Copyright (c) 2014年 v5mcs. All rights reserved.
//

#import "YYService_YYWithBigTableForMyCell_TableViewCell.h"

@implementation YYService_YYWithBigTableForMyCell_TableViewCell

/*
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        //添加服务商图片
        self.serviceProvidersImageView = [[UIImageView alloc]initWithFrame:CGRectMake(8, 8, 100, 82)];
        [self.serviceProvidersImageView setImage:[UIImage imageNamed:@"商家图片.png"]];
        [self.contentView addSubview:self.serviceProvidersImageView];
        
        //添加服务商名字
        self.serviceProvidersNameLabel = [[UILabel alloc]initWithFrame:CGRectMake(118, 8, 100, 21)];
        self.serviceProvidersNameLabel.text = @"服务商名字";
        self.serviceProvidersNameLabel.font = [UIFont systemFontOfSize:14];
        self.serviceProvidersNameLabel.textColor = [UIColor purpleColor];
        [self.contentView addSubview:self.serviceProvidersNameLabel];
        
        //添加服务商地址
        self.serviceProvidersAddressLabel = [[UILabel alloc]initWithFrame:CGRectMake(118, 70, 100, 21)];
        self.serviceProvidersAddressLabel.text = @"服务商地址";
        self.serviceProvidersAddressLabel.font = [UIFont systemFontOfSize:12];
        [self.contentView addSubview:self.serviceProvidersAddressLabel];
        
        //添加服务商距离
        self.serviceProvidersDistanceLabel = [[UILabel alloc]initWithFrame:CGRectMake(258, 70, 100, 21)];
        self.serviceProvidersDistanceLabel.text = @"服务商距离";
        self.serviceProvidersDistanceLabel.font = [UIFont systemFontOfSize:12];
        [self.contentView addSubview:self.serviceProvidersDistanceLabel];
    }
    
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}
*/

@end
