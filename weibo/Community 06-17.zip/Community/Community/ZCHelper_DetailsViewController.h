//
//  ZCHelp_DetailsViewController.h
//  Community
//
//  Created by yuxin tang on 14-4-16.
//  Copyright (c) 2014年 v5mcs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZCHelper_DetailsViewController : UIViewController<UISplitViewControllerDelegate>

@property (strong, nonatomic) id detailItem;

@property (strong, nonatomic) IBOutlet UILabel *viewControllerLabel;
@end
