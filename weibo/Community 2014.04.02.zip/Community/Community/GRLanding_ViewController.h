//
//  GRLanding_ViewController.h
//  Community
//
//  Created by WEB08-V5MCS006 on 14-3-31.
//  Copyright (c) 2014年 v5mcs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GRLanding_ViewController : UIViewController

@property (strong, nonatomic) IBOutlet UITextField *nameOrNumberTextField;
@property (strong, nonatomic) IBOutlet UITextField *passwordTextField;

- (IBAction)textFieldDone:(id)sender;

@end
