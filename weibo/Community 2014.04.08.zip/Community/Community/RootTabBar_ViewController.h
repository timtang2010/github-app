//
//  RootTabBar_ViewController.h
//  Community
//
//  Created by WEB08-V5MCS006 on 14-4-1.
//  Copyright (c) 2014年 v5mcs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootTabBar_ViewController : UITabBarController

@property (strong, nonatomic) NSMutableArray * images;
@property (strong, nonatomic) NSMutableArray * selectImages;

- (void)createCustomTabBar;//声明自定义tabBar方法
- (void)createSpaceImageView;//声明间隔图片的创建方法

@end
