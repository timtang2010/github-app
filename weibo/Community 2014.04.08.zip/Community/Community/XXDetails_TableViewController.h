//
//  ZCDetails_TableViewController.h
//  Community
//
//  Created by yuxin tang on 14-3-27.
//  Copyright (c) 2014年 v5mcs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XXDetails_TableViewController : UITableViewController
@property (weak, nonatomic) NSArray *listData;

@end
